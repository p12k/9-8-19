import { Component } from '@angular/core';

@Component({
  selector: 'edit-root',
  templateUrl: './edit.component.html',
 styleUrls: ['./edit.component.css']
})
export class EditComponent {
  title = 'Edit';
}
