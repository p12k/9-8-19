export class User{
constructor(
public courierid ='',
public name ='',
public email ='',
public contact=''
)

{}

}
   